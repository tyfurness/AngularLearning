import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styles: [`
  .whiteColor{
    color:white;
  }
  `]
})
export class AppComponent {
  count: number = 0;
  timesClicked: Array<number> = [];

  onDisplayDetails(){
    this.count++;
    this.timesClicked.push(this.count);
  }
}
